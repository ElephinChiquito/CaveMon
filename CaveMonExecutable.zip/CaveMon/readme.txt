🎮 CaveMon – Versión para Windows

📦 Instrucciones para iniciar el juego:

1. Haz doble clic en el archivo `CaveMon.exe`.
2. El juego se abrirá automáticamente sin necesidad de instalar Java.
3. El icono del archivo debe coincidir con la imagen del juego. Si no aparece, asegúrate de no haber modificado el nombre o extensión del archivo.

🎧 Requisitos:

- Sistema operativo: Windows 10 o superior
- No requiere instalación de Java (incluye entorno embebido)
- Se recomienda pantalla HD y altavoces/auriculares para disfrutar del sonido

📁 Estructura de carpetas:

- `CaveMon.exe` → Lanzador del juego
- `CaveMon.jar` → Juego en sí
- `jre/` → Java embebido necesario para funcionar
- `Images/` → Recursos gráficos
- `Audio/` → Música y efectos de sonido
- `readme.txt` → Este archivo

❗ Importante:
- No elimines ni muevas las carpetas `jre`, `Images` o `Audio`.
- No ejecutes `CaveMon.jar` directamente, siempre usa `CaveMon.exe`.

📬 Contacto:
Si encuentras algún error o quieres enviar sugerencias, por favor contacta al desarrollador a través de la página de itch.io del Proyecto, o puedes directamente escribir a malmonacidandres@gmail.com.

¡Gracias por jugar a CaveMon! 🕹️🔥
